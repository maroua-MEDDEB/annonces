<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{

    /**
     * @Route("/hello/{prenom}/{age}", name="hello_base")
     */
    public function hello($prenom ="anonyme", $age = 0):Response
    {
        return  $this->render('home/hello.html.twig',
        ['title'=>  "bonjour " . $prenom . " vous avez " . $age. " ans."] );

    }

    /**
     * @Route("/", name="homepage")
     */
    public function home(): Response
    {
        $prenoms=["maroua"=>31, "amira"=>34, "mohamed"=>23];

        return $this->render('home/index.html.twig', [
            'titre' => 'bonjour à tous!',
            'age'=>18,
            'tableau'=> $prenoms
        ]);
    }
}
